const assert = require('assert');

describe('Basic System Monitor Test', function () {
  it('should always return true', function () {
    assert.strictEqual(true, true);
  });
});
